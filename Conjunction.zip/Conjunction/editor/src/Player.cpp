#include "stdafx.h"

#include "Player.h"

namespace capstone {

	/** 
	 * Player constructor.
	 */
	Player::Player() {

	}

	/** 
	 * Player destructor.
	 */
	Player::~Player() {

	}

}