#ifndef capstone_GLOBALS_VARS_H_
#define capstone_GLOBALS_VARS_H_

namespace capstone {

	// Gravity acceleration vector.
    const Ogre::Vector3 gGravity(0, -9.8f, 0);
}

#endif
