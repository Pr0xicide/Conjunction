#ifndef capstone_BUILDINGS_H_
#define capstone_BUILDINGS_H_

#include "InteractiveBuilding.h"
#include "RoomBuilding.h"
#include "FactoryBuilding.h"
#include "LaunchBuilding.h"

#endif