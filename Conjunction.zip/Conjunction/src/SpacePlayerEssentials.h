#ifndef capstone_SPACEPLAYERESSENTIALS_H_
#define capstone_SPACEPLAYERESSENTIALS_H_

#include "Part.h"
#include "CompletePart.h"
#include "ReallocState.h"
#include "Attributes.h"
#include "Projectile.h"
#include "skills.h"
#include "GlobalVariables.h"
#include "Levels.h"
#include "gamestates.h"

#endif