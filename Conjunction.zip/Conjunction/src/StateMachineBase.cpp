#include "stdafx.h"

#include "StateMachineBase.h"
#include "Enemy.h"

namespace capstone {
	
	/**
	 * StateMachineBase constructor.
	 */
	/*StateMachineBase::StateMachineBase() {
		mAIState = AIStates_Idle;
	}*/

	/**
	 * StateMachineBase destructor.
	 */
	/*StateMachineBase::~StateMachineBase() {

	}*/
	
}
