#include "stdafx.h"

//
// This file intentionally left blank.
// Its sole purpose is to trigger the generation of precompiled headers.
//
