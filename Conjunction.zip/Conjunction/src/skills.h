#ifndef capstone_SKILLS_H_
#define capstone_SKILLS_H_

#include "Skill.h"
#include "MeleeSkill.h"
#include "ProjectileSkill.h"
#include "PassiveSkill.h"

#endif