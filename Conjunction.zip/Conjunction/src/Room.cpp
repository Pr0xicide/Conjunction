#include "stdafx.h"

#include "Room.h"

namespace capstone {
	
	/**
	 * Room constructor.
	 */
	Room::Room() {

	}

	/**
	 * Room destructor.
	 */
	Room::~Room() {

	}
	
}