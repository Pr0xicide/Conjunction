#include "stdafx.h"

#include "Level.h"

namespace capstone {
	
	/**
	 * Level constructor.
	 */
	Level::Level() {

	}

	/**
	 * Level destructor.
	 */
	Level::~Level() {

	}
	
}
