#ifndef capstone_ANIMATIONS_H_
#define capstone_ANIMATIONS_H_

#include "AnimationState.h"
#include "PlayerWalkState.h"
#include "PlayerIdleState.h"
#include "PlayerShootState.h"

#endif