#ifndef capstone_tinyxmls_H_
#define capstone_tinyxmls_H_

#include "tinystr.h"
#include "tinyxml.h"
#include "tinyxmls.h"

#endif