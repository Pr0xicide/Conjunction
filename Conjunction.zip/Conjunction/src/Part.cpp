#include "stdafx.h"

#include "Part.h"

namespace capstone {

	/**
	 * Part constructor.
	 */
	Part::Part() {

	}

	/**
	 * Part destructor.
	 */
	Part::~Part() {

	}

}