#ifndef capstone_RESOURCES_H_
#define capstone_RESOURCES_H_

#include "Resource.h"
#include "DarkMatter.h"
#include "MetalScrap.h"
#include "Carbon.h"

#endif