#ifndef capstone_AISTATES_H_
#define capstone_AISTATES_H_

#include "StateMachineBase.h"
#include "ApproachState.h"
#include "AttackState.h"
#include "DieState.h"
#include "IdleState.h"
#include "WanderState.h"

#endif