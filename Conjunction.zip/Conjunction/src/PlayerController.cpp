#include "stdafx.h"

#include "PlayerController.h"

namespace capstone {

	/**
	 * PlayerController constructor.
	 */
	PlayerController::PlayerController() {

	}

	/**
	 * PlayerController destructor.
	 */
	PlayerController::~PlayerController() {

	}

}
